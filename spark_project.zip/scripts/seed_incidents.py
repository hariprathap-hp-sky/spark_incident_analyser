"""
Seed Postgres with the sample incidents from spark_incidents/*.txt.

These .txt files are already formatted (Incident ID / Date / Cluster /
Application / Error Summary / Work Notes), so this script parses them back
into raw columns and inserts them as RESOLVED, ingested=FALSE rows.

This lets you test the REAL ingestion path (backend/data_pipeline.py)
end-to-end instead of upserting directly into Qdrant.

Usage:
    python -m scripts.seed_incidents
"""

from __future__ import annotations

import re
from pathlib import Path

import psycopg2

from backend.config import cfg

INCIDENTS_DIR = Path(__file__).parent.parent / "spark_incidents"


def _parse_file(path: Path) -> dict:
    text = path.read_text()

    def field(name: str) -> str:
        m = re.search(rf"^{name}:\s*(.+)$", text, re.MULTILINE)
        return m.group(1).strip() if m else ""

    work_notes_match = re.search(r"Work Notes:\n(.*)", text, re.DOTALL)
    work_notes = work_notes_match.group(1).strip() if work_notes_match else ""

    return {
        "incident_id": field("Incident ID"),
        "created_date": field("Date"),
        "cluster": field("Cluster"),
        "application": field("Application"),
        "description": field("Error Summary"),
        "work_notes": work_notes,
    }


def main() -> None:
    files = sorted(INCIDENTS_DIR.glob("*.txt"))
    print(f"Found {len(files)} incident files in {INCIDENTS_DIR}")

    rows = [_parse_file(f) for f in files]

    db = cfg.database
    conn = psycopg2.connect(
        host=db.host, port=db.port, dbname=db.name, user=db.user, password=db.password
    )
    try:
        with conn.cursor() as cur:
            for row in rows:
                cur.execute(
                    """
                    INSERT INTO incidents
                        (incident_id, created_date, cluster, application,
                         description, work_notes, status, ingested)
                    VALUES (%s, %s, %s, %s, %s, %s, 'RESOLVED', FALSE)
                    ON CONFLICT (incident_id) DO NOTHING
                    """,
                    (
                        row["incident_id"],
                        row["created_date"],
                        row["cluster"],
                        row["application"],
                        row["description"],
                        row["work_notes"],
                    ),
                )
        conn.commit()
        print(f"Seeded {len(rows)} incidents (duplicates skipped).")
    finally:
        conn.close()


if __name__ == "__main__":
    main()